class TemplateAi:
    def __init__(self):
        pass # algoritimo todo como na aula . get move await 
    def get_move(self, slots, foundations):
        return 0,0,0