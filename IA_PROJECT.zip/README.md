# 🃏 Double Solitaire

**Double Solitaire** é um jogo de cartas desenvolvido em **Python** utilizando a biblioteca **Pygame**. Este projeto inclui modos de jogo para humanos e inteligência artificial (IA), além de várias opções de personalização e configurações.

---

## 📦 Pré-requisitos

Antes de executar o projeto, certifique-se de que os seguintes requisitos estão instalados no seu sistema:

- **Python 3.8 ou superior**
- **Pygame 2.6.1** (ou versão compatível)
- **ConfigParser 7.2.0**

---

## 🚀 Instalação

```bash

📥 Clonar o Repositório
git clone https://github.com/user/DoubleSolitaire.git

📁 Navegar até o diretório do projeto
cd c:...\IA project\FEUP-IART\pj1\DoubleSolitaire

📦 Instalar as dependências
pip install -r requirements.txt

````
## ▶️ Execução

```bash
▶️Para iniciar o jogo:
python run.py
````


## 🎮 Como Jogar

### 🏠 Menu Principal

Ao iniciar o jogo, você verá o **menu principal** com as seguintes opções:

- **PLAY**: Inicia um novo jogo.
- **OPTIONS**: Permite ajustar configurações como resolução, dificuldade e IA.
- **LOAD GAME**: Carrega um jogo salvo anteriormente.
- **QUIT**: Sai do jogo.

---

### 🕹️ Durante o Jogo

#### 🎴 Movimentação de Cartas

- Clique e arraste as cartas para movê-las entre os slots ou para as fundações.
- Clique duas vezes em uma carta para movê-la automaticamente para a fundação, se possível.

#### 📚 Barra Lateral

- **Main Menu**: Retorna ao menu principal.
- **Undo**: Desfaz o último movimento.
- **Options**: Abre o menu de opções.
- **Hint**: Mostra uma dica de movimento.
- **Save**: Salva o estado atual do jogo.

---

### ⌨️ Controles

#### 🖱️ Mouse

- **Clique esquerdo**: Seleciona e move cartas.
- Clique nos botões da interface para interagir com o jogo.

#### ⌨️ Teclado

- **R**: Reinicia o jogo.
- **M**: Retorna ao menu principal.
- **F**: Alterna entre modo de tela cheia e janela.
- **ESC**: Sai do jogo.

## ⚙️ Configurações

As configurações do jogo podem ser ajustadas no arquivo **config.cfg**. Aqui estão algumas opções disponíveis:

### 🖥️ Resolução

- **reswidth** e **resheight**: Define a largura e altura da janela do jogo.

### 🖥️ Modo de Tela Cheia

- **fullscreen**: Define se o jogo será iniciado em tela cheia (`True` ou `False`).

### ⚡ Outras Opções

- **fast mode**: Ativa ou desativa o modo rápido.
- **no anims**: Remove animações para uma experiência mais rápida.
- **difficulty**: Define a dificuldade inicial do jogo (`easy`, `medium`, `hard`).

## Modos de IA

O jogo suporta diferentes algoritmos de Inteligência Artificial (IA) para jogar automaticamente:

1. **DFS (Busca em Profundidade)**  
   Explora todos os movimentos possíveis até encontrar uma solução. Este método é exaustivo e garante encontrar uma solução, mas pode ser ineficiente em jogos com muitos estados possíveis.

2. **Uniform Cost Search (Busca de Custo Uniforme)**  
   Utiliza heurísticas para encontrar o melhor caminho para a vitória. Este método prioriza movimentos com menor custo, tornando-o mais eficiente em encontrar soluções otimizadas.

3. **BFS**
   Explora os movimentos por níveis, garantindo encontrar a solução mais próxima primeiro. É eficaz para encontrar soluções rápidas, mas pode consumir muita memória em jogos com grandes árvores de decisão.

4. **A-Star**
   Combina custo de caminho com heurísticas para escolher os movimentos mais promissores. É eficiente e focado, ideal para encontrar soluções ótimas com menor número de passos.







